import React , { useState , useEffect } from 'react';
import 'react-clock';

function Clock() {
    const [value, setValue] = useState(new Date());

    useEffect(() => {
        const interval = setInterval(
            () => setValue(new Date())
            , 1000)

            return () => {
                clearInterval(interval)}
    }, [])

    return (
        <div>
            <h3>Current time:</h3>
            <Clock value={value} />
        </div>
    )
}

export default Clock
